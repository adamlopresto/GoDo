package fake.domain.adamlopresto.godo;

public enum RepetitionRuleColumns {
    NEW_START, NEW_PLAN, NEW_DUE, NOW, OLD_START, OLD_PLAN, OLD_DUE
}
