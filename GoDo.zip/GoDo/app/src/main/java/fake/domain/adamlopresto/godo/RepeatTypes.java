package fake.domain.adamlopresto.godo;

public enum RepeatTypes {
    NONE, AUTOMATIC, TEMPLATE
}
