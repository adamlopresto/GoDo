package fake.domain.adamlopresto.godo;

public enum NotificationLevels {
    NONE, SILENT, VIBRATE, NOISY, SPOKEN
}
