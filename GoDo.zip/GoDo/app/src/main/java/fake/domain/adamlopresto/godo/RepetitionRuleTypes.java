package fake.domain.adamlopresto.godo;

public enum RepetitionRuleTypes {
    ADD_DAY, ADD_MONTH, WEEKDAY, ADD_WEEK, ADD_YEAR, SET_TIME
}
